﻿using System.Windows;

namespace LogExplorer
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void LogLineViewControl_Loaded(object sender, RoutedEventArgs e)
        {
            ViewModel.LogVM loglineVM =new ViewModel.LogVM();
            LogLineViewControl.DataContext = loglineVM;
        } 
    }
}
